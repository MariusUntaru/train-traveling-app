﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Marnie
{
	public interface ILocalize
	{
		///	<summary>
		/// This method must evaluate platform-specific locale settings
		/// and convert them (when necessary) to a valid .NET locale.
		/// </summary>
		CultureInfo GetCurrentCultureInfo();

		/// <summary>
		/// CurrentCulture and CurrentUICulture must be set in the platform project, 
		/// because the Thread object can't be accessed in a PCL.
		/// </summary>
		void SetLocale(CultureInfo ci);
	}

	public class PlatformCulture
	{
		public PlatformCulture(string platformCultureString)
		{
			if (String.IsNullOrEmpty(platformCultureString))
				throw new ArgumentException("Expected culture identifier", "platformCultureString");

			PlatformString = platformCultureString.Replace("_", "-"); 
			var dashIndex = PlatformString.IndexOf("-", StringComparison.Ordinal);
			if (dashIndex > 0)
			{
				var parts = PlatformString.Split('-');
				LanguageCode = parts[0];
				LocaleCode = parts[1];
			}
			else
			{
				LanguageCode = PlatformString;
				LocaleCode = "";
			}
		}
		public string PlatformString { get; private set; }
		public string LanguageCode { get; private set; }
		public string LocaleCode { get; private set; }
		public override string ToString()
		{
			return PlatformString;
		}
	}
}
