﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Marnie.Model;
using Marnie.MultilingualResources;
using RestSharp;

namespace Marnie.Services
{
    public class RouteService
    {
        
    }
}
